package foundry.veil.api.flare.data.effect;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import foundry.veil.api.client.render.MatrixStack;
import foundry.veil.api.flare.EffectHost;
import foundry.veil.api.flare.FlareEffectManager;
import foundry.veil.api.flare.model.BakedShell;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import static foundry.veil.Veil.LOGGER;

/**
 * @since 2.5.0
 */
public record FlareSubModule(List<ResourceLocation> templates) {

    public static final Codec<FlareSubModule> CODEC = Codec.either(
                    ResourceLocation.CODEC.listOf(),
                    ResourceLocation.CODEC
            )
            .xmap(either -> either.map(FlareSubModule::new, single -> new FlareSubModule(List.of(single))),
                    subModule -> subModule.templates.size() == 1 ? Either.right(subModule.templates.getFirst()) : Either.left(subModule.templates));

    public FlareSubModule(List<ResourceLocation> templates) {
        this.templates = Collections.unmodifiableList(templates);
    }

    public void render(EffectHost host, MatrixStack matrixStack, float partialTick) {
        this.render(host, matrixStack, partialTick, null);
    }

    public void render(EffectHost host, MatrixStack matrixStack, float partialTick, @Nullable Map<ResourceLocation, BakedShell> shellOverrides) {
        for (ResourceLocation templateLocation : this.templates) {
            FlareEffectTemplate template = FlareEffectManager.getTemplate(templateLocation);
            if (template == null) {
                LOGGER.error("Template {} could not be found!", templateLocation);
                continue;
            }
            template.render(host, matrixStack, partialTick, shellOverrides);
        }
    }
}
