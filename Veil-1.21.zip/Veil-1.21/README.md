# Veil: Advanced Rendering for Minecraft 🖼️✨

[![Veil 1.21.1](https://img.shields.io/maven-metadata/v?metadataUrl=https%3A%2F%2Fmaven.blamejared.com%2Ffoundry%2Fveil%2Fveil-common-1.21.1%2Fmaven-metadata.xml&label=Veil%201.21.1)](https://maven.blamejared.com/foundry/veil/veil-common-1.21.1/)
[![Javadoc](https://img.shields.io/badge/javadoc-latest-blue)](https://foundrymc.github.io/Veil/)
[![Discord](https://img.shields.io/discord/1022254439836430386.svg?label=Discord&color=blue)](https://discord.com/invite/2aqTX9QWKU)

Veil is a sophisticated collection of tools and utilities designed to facilitate advanced rendering for Minecraft mod
developers. Our goal is to enable more modern game-engine level content in Java Minecraft, pushing the boundaries of
what is possible in modding.

## Features

- **Colors**: Manage colors and use them with Themes.
- **Easings**: Apply easing functions for more natural motion.
- **Framebuffer**: JSON-driven custom framebuffers.
- **Post Processing**: A custom post-processing pipeline with easy texture binding.
- **Shaders**: Full support for all OpenGL shader types, with HLSL and Spir-V support potentially coming in the future.
- **Shader Modification**: Inject and modify existing shaders to suit your needs.
- **Necromancer**: Bone-based animated models with support for independent entity skeletons and models.

## Getting Started

Explore our [Example Mod](https://github.com/FoundryMC/veil-example-mod) to see Veil in action and learn how to
integrate it into your projects.

For comprehensive documentation and guides, visit our [Veil Developer Wiki](https://github.com/FoundryMC/Veil/wiki).

## Contribution Guidelines

We welcome contributions from the community! Before contributing, please read
our [Contributing Guidelines](CONTRIBUTING.md) to understand our processes and ensure your contributions align with the
project goals.

## Code of Conduct

Please note that we expect all contributors to adhere to our [Code of Conduct](CODE_OF_CONDUCT.md). Respectful and
constructive interactions are crucial for maintaining a positive and collaborative community.

## License

Veil is licensed under the [LGPL License](LICENSE). Feel free to use, modify, and distribute the code as per the terms
of the license.

## Goals

Our primary goal with Veil is to enable the creation of more modern, game engine-level content within Java Minecraft. We
strive to provide mod developers with the tools they need to push the boundaries of what is possible in Minecraft
modding, bringing new and exciting experiences to players.

## Contact

If you have any questions, feel free to reach out to us through the issues section on GitHub. We're here to help and
appreciate your efforts to improve Veil!
